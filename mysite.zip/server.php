<?php
//connect to database
$db=mysqli_connect('localhost','shubham__singh','bitcoin@2896','blogcomments');

//if the register button is clicked
if (isset($_POST['users'])) {
	$name = $_POST['name'];
	$email = $_POST['email'];
	$comment = $_POST['comment'];
	
	$sql= "INSERT INTO users (name, email, comment) VALUES ('$name', '$email', '$comment')";
	mysqli_query($db, $sql);
	
}
?>