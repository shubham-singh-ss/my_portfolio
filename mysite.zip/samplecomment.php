<?php
//connect to database
$db=mysqli_connect('localhost','shubham__singh','bitcoin@2896','blogcomments');

//if the register button is clicked
if (isset($_POST['users'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $comment = $_POST['comment'];
  
  $sql= "INSERT INTO users (name, email, comment) VALUES ('$name', '$email', '$comment')";
  mysqli_query($db, $sql);
  
}
?>
<html>
<head>
  <title>User registration</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


  <div class="header">
    <h2>Register</h2>

  </div>
              <form action="samplecomment.php" method="post">
                  <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input class="form-control" type="text" name="name" placeholder="Your Name *" required data-validation-required-message="Please enter your name.">
               
                  </div>
                  <div class="form-group">
                    <input class="form-control" type="email" name="email" placeholder="Your Email *" required data-validation-required-message="Please enter your email address.">
                   </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <textarea class="form-control" name="comment" placeholder="Your Message *" row="10" required data-validation-required-message="Please enter a message."></textarea>
                
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-lg-12 text-center">
                  <div id="success"></div>
                  <button id="sendMessageButton" class="btn btn-primary btn-xl text-uppercase" type="submit">Send Message</button>
                </div>
              </div>
            </form>

</body>
</html>